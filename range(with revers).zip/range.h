#pragma once

#ifndef RANGE_H
#define RANGE_H

#include <iostream>

#define REVERSE_RANGE_IMPLEMENTED

class Range {
 public:
  int m_begin;
  int m_end;
  int m_step;
  class Iterator {
   public:
    int m_current;
    int m_step;
    int mi_end;
    Iterator(const int& current, const int& step, const int& m_end) : m_current(current), m_step(step), mi_end(m_end) {
    }

    bool operator!=(const Iterator& other) const {
      return m_current != other.m_current;
    }

    int operator*() const {
      return m_current;
    }

    const Iterator& operator++() {
      m_current += m_step;
      if (mi_end < m_current && m_step > 0) {
        m_current = mi_end;
        return *this;
      }
      if (mi_end > m_current && m_step < 0) {
        m_current = mi_end;
        return *this;
      }
      return *this;
    }
  };
  class ReverseIterator {
   public:
    int m_current;
    int m_step;
    int mi_begin;
    ReverseIterator(const int& current, const int& step, const int& m_begin)
        : m_current(current), m_step(step), mi_begin(m_begin) {
    }

    bool operator!=(const ReverseIterator& other) const {
      return m_current != other.m_current;
    }

    int operator*() const {
      return m_current;
    }

    const ReverseIterator& operator++() {
      m_current += m_step;
      if (mi_begin > m_current && m_step < 0) {
        m_current = mi_begin;
        return *this;
      }
      if (mi_begin < m_current && m_step > 0) {
        m_current = mi_begin;
        return *this;
      }
      return *this;
    }
  };
  explicit Range(const int& end) : m_begin(0), m_end(end), m_step(1) {
    if (end <= 0) {
      m_end = 0;
    }
  }
  Range(const int& begin, const int& end) : m_begin(begin), m_end(end), m_step(1) {
    if (m_end < m_begin) {
      m_end = m_begin;
    }
  }
  Range(const int& begin, const int& end, const int& step) : m_begin(begin), m_end(end), m_step(step) {
    if (m_end < m_begin && m_step > 0) {
      m_end = m_begin;
    }
    if (m_end > m_begin && m_step < 0) {
      m_end = m_begin;
    }
    if (m_step == 0) {
      m_end = m_begin;
    }
  }

  Iterator begin() const {  // NOLINT
    return Iterator(m_begin, m_step, m_end);
  }
  Iterator end() const {  // NOLINT
    return Iterator(m_end, m_step, m_end);
  }
  ReverseIterator rbegin() const {  // NOLINT
    int f = m_begin;
    if (m_step > 0) {
      while (f + m_step < m_end) {
        f += m_step;
      }
    } else if (m_step < 0) {
      while (f + m_step > m_end) {
        f += m_step;
      }
    }
    if (m_end == m_begin) {
      return ReverseIterator(m_begin, m_step, m_begin);
    }
    return ReverseIterator(f, -m_step, m_begin - m_step);
  }
  ReverseIterator rend() const {  // NOLINT
    if (m_end == m_begin) {
      return ReverseIterator(m_begin, m_step, m_begin);
    }
    return ReverseIterator(m_begin - m_step, -m_step, m_begin - m_step);
  }
};

#endif