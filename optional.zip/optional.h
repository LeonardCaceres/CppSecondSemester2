#pragma once

#include <iostream>
#include <exception>

class BadOptionalAccess : public std::exception {};

template <typename T>
class Optional {
 public:
  std::aligned_storage_t<sizeof(T), alignof(T)> arr_storage;
  void* arr_value_ptr;
  bool arr_has_value;
  Optional() : arr_value_ptr(nullptr), arr_has_value(false) {
  }

  Optional(const Optional& other) : arr_value_ptr(nullptr), arr_has_value(false) {
    if (other.arr_has_value) {
      Emplace(*reinterpret_cast<const T*>(other.arr_value_ptr));
    } else {
      arr_has_value = false;
      arr_value_ptr = nullptr;
    }
  }

  Optional(Optional&& other) : arr_value_ptr(nullptr), arr_has_value(false) {  // NOLINT
    if (other.arr_has_value) {
      Emplace(std::move(*reinterpret_cast<T*>(other.arr_value_ptr)));
    } else {
      arr_has_value = false;
      arr_value_ptr = nullptr;
    }
  }

  Optional(const T& value) : arr_value_ptr(nullptr), arr_has_value(false) {  // NOLINT
    Emplace(value);
  }

  Optional(T&& value) : arr_value_ptr(nullptr), arr_has_value(false) {  // NOLINT
    Emplace(value);
  }

  ~Optional() {
    Reset();
  }

  Optional& operator=(const Optional& other) {
    if (this != &other) {
      if (other.arr_has_value) {
        Emplace(*reinterpret_cast<const T*>(other.arr_value_ptr));
      } else {
        this->~Optional();
      }
    }
    return *this;
  }

  Optional& operator=(Optional&& other) {
    if (this != &other) {
      if (other.arr_has_value) {
        Emplace(std::move(*reinterpret_cast<T*>(other.arr_value_ptr)));
      } else {
        this->Reset();
        this->arr_has_value = false;
      }
    }
    return *this;
  }

  Optional& operator=(const T& value) {
    Optional<T> del(value);
    if (this->arr_value_ptr != del.arr_value_ptr) {
      if (this->arr_has_value) {
        this->Reset();
      }
      Emplace(value);
    }
    del.Reset();
    return *this;
  }

  Optional& operator=(T&& value) {
    if (this->arr_has_value) {
      this->Reset();
    }
    Emplace(std::move(value));
    return *this;
  }

  bool HasValue() const {
    return arr_has_value;
  }

  explicit operator bool() const {
    return HasValue();
  }

  T& Value() & {
    if (!HasValue()) {
      throw BadOptionalAccess();
    }
    return *reinterpret_cast<T*>(arr_value_ptr);
  }

  const T& Value() const & {
    if (!HasValue()) {
      throw BadOptionalAccess();
    }
    return *reinterpret_cast<const T*>(arr_value_ptr);
  }

  T&& Value() && {
    if (!HasValue()) {
      throw BadOptionalAccess();
    }
    return std::move(*reinterpret_cast<T*>(arr_value_ptr));
  }

  const T&& Value() const && {
    if (!HasValue()) {
      throw BadOptionalAccess();
    }
    return std::move(*reinterpret_cast<const T*>(arr_value_ptr));
  }

  T& operator*() & {
    return Value();
  }

  const T& operator*() const & {
    return Value();
  }

  T&& operator*() && {
    return std::move(Value());
  }

  const T&& operator*() const && {
    return std::move(Value());
  }

  template <typename... Args>
  T& Emplace(Args&&... args) {
    if (arr_has_value) {
      Reset();
    }
    new (&arr_storage) T(std::forward<Args>(args)...);
    arr_has_value = true;
    arr_value_ptr = &arr_storage;
    return Value();
  }

  void Reset() {
    if (arr_has_value) {
      reinterpret_cast<T*>(arr_value_ptr)->~T();
      arr_has_value = false;
      arr_value_ptr = nullptr;
    }
  }

  void Swap(Optional& other) {
    if (arr_has_value && other.arr_has_value) {
      std::swap(*reinterpret_cast<T*>(arr_value_ptr), *reinterpret_cast<T*>(other.arr_value_ptr));
    } else if (arr_has_value) {
      other = std::move(*this);
      this->arr_has_value = false;
    } else if (other.arr_has_value) {
      *this = std::move(other);
      other.arr_has_value = false;
    }
  }
};